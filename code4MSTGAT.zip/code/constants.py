CHARACTER = 'character'
WORD = 'word'
TOKEN_PATTERN = r"(?u)\b\w\w+\b|<\w*>|\?|\"|\'"

MODELS = ['bow', 'binary_bow', 'boc']