#!/usr/bin/env python
# coding: utf-8

# rgcn

import math
import torch
import torch.nn as nn
from torch.nn.parameter import Parameter
import torch.nn.functional as F
from torch.nn.modules.module import Module
from torch.nn.modules.utils import _single, _pair, _triple
from torch.autograd import Variable
from models.layers import *
from vae.vae import VAE


class TemporalConv(nn.Module):
    r"""Temporal convolution block applied to nodes in the STGCN Layer
    For details see: `"Spatio-Temporal Graph Convolutional Networks:
    A Deep Learning Framework for Traffic Forecasting." 
    <https://arxiv.org/abs/1709.04875>`_ Based off the temporal convolution
     introduced in "Convolutional Sequence to Sequence Learning"  <https://arxiv.org/abs/1709.04875>`_
    Args:
        in_channels (int): Number of input features.
        out_channels (int): Number of output features.
        kernel_size (int): Convolutional kernel size.
    """
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int=3):
        super(TemporalConv, self).__init__()
        # 使用padding，保证temporalConv的输入输出保持一致
        # self.conv_1 = nn.Conv2d(in_channels, out_channels, (1, kernel_size), padding=(0, (kernel_size-1)//2))
        # self.conv_2 = nn.Conv2d(in_channels, out_channels, (1, kernel_size), padding=(0, (kernel_size-1)//2))
        # self.conv_3 = nn.Conv2d(in_channels, out_channels, (1, kernel_size), padding=(0, (kernel_size-1)//2))
        # 不适用padding
        self.conv_1 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv_2 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv_3 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))

    def forward(self, X: torch.FloatTensor) -> torch.FloatTensor:
        """Forward pass through temporal convolution block.
        
        Arg types:
            * **X** (torch.FloatTensor) -  Input data of shape 
                (batch_size, input_time_steps, num_nodes, in_channels).
        Return types:
            * **H** (torch.FloatTensor) - Output data of shape 
                (batch_size, in_channels, num_nodes, input_time_steps).
        """
        # X.shape: (32, 27, 5)
        X = X.permute(0, 3, 1, 2)  # torch.Size([64, 1, 27, 5])
        P = self.conv_1(X)
        Q = torch.sigmoid(self.conv_2(X))
        PQ = P * Q
        H = F.relu(PQ + self.conv_3(X))
        H = H.permute(0, 2, 3, 1)
        return H



class RelationalGraphConvModel(nn.Module):
    def __init__(
        self,
        input_size,
        hidden_size,
        output_size,
        num_bases,
        num_rel,
        num_layer,
        dropout,
        kernel,
        ajacency_matrix,
        config,
        checkpoint_directory,
        featureless=True,
        cuda=False,
    ):
        super(RelationalGraphConvModel, self).__init__()

        self.num_layer = num_layer
        self.dropout = dropout
        self.layers = nn.ModuleList()
        self.relu = nn.ReLU()
        self.ajacency_matrix = ajacency_matrix.cuda()
        self.hidden_size = hidden_size
        # self.lstm = nn.LSTM(hidden_size, output_size, 2, dropout=dropout, bidirectional=True).cuda()
        # self.lstm = nn.LSTM(hidden_size, output_size, 2, dropout=dropout).cuda()
        # self.lstm = nn.LSTM(input_size, output_size, 2, dropout=dropout).cuda()
        # self.lstm = nn.LSTM(2*input_size-kernel+1, output_size, 2, dropout=dropout).cuda()

        self.temporal_conv = TemporalConv(in_channels=1, 
                                    out_channels=1, 
                                    kernel_size=kernel).cuda()
        self.temporal_conv_2 = TemporalConv(in_channels=1, 
                                    out_channels=1, 
                                    kernel_size=kernel).cuda()

        for i in range(self.num_layer):
            if i == 0:
                self.layers.append(
                    RelationalGraphConvLayer(
                        input_size-kernel+1,  # with_temporal_conv: input_size-kernel+1
                        # input_size, # no_temporal_conv: input_size
                        hidden_size,
                        num_bases,
                        num_rel,
                        bias=False,
                        cuda=cuda,
                    )
                )
            else:
                if i == self.num_layer - 1:
                    self.layers.append(
                        RelationalGraphConvLayer(
                            hidden_size,
                            hidden_size,  # use_lstm or vae: hidden_size
                            # input_size,  #  并联输入给lstm 
                            # output_size,  #  no_lstm or vae: output_size 
                            num_bases,
                            num_rel,
                            bias=False,
                            cuda=cuda,
                        )
                    )
                else:
                    self.layers.append(
                        RelationalGraphConvLayer(
                            hidden_size,
                            hidden_size,
                            num_bases,
                            num_rel,
                            bias=False,
                            cuda=cuda,
                        )
                    )
        
        self.predictor = nn.Linear(hidden_size, output_size).cuda()
        # self.vae = VAE(input_size, config, checkpoint_directory).cuda()
        self.vae = VAE(hidden_size, config, checkpoint_directory).cuda()

    # 串联: TCN->GCN->(linear+vae)
    def forward(self, X):
        X_vae = X.clone()
        X = self.temporal_conv(X.unsqueeze(-1)).squeeze(-1)
        for i, layer in enumerate(self.layers):
            # A = torch.randint(0, 2, (2, 27, 27)).float().cuda()
            if(i==0):
                x = layer(self.ajacency_matrix, X)
            else:
                x = layer(self.ajacency_matrix, x)
            if i != self.num_layer - 1:
                x = F.dropout(self.relu(x), self.dropout, training=self.training)
            else:
                x = F.dropout(x, self.dropout, training=self.training)
            
        # 调用vae
        # X_vae = torch.randn(64, 27, 100).cuda()  #!!!
        vae_input = x.view(-1, self.hidden_size)
        # vae_input = X_vae
        logtheta = self.vae.forward(vae_input)
        # loglikelihood = -self.vae.loglikelihood(reduction='sum')(logtheta, vae_input) / vae_input.shape[0]
        loglikelihood = -self.vae.loglikelihood(reduction='mean')(logtheta, vae_input) / vae_input.shape[0]
        kl_div = -0.5 * torch.sum(1 + self.vae.logvar - self.vae.mu.pow(2) - self.vae.logvar.exp()) / vae_input.shape[0]
        loss_vae = -loglikelihood + kl_div


        x = self.predictor(x)

        # if h==None:
        #     x, (hn, cn) = self.lstm(x)# !!!add
        # else:
        #     x, (hn, cn) = self.lstm(x, (h, c))  # !!!add
        # # x = (x.sum(-1)/2) # bidirectional
        if(x.shape[-1]==1):
            x = x.squeeze(-1)
        return x, loss_vae, kl_div, loglikelihood

    # 并联: TCN+GCN->LSTM
    # def forward(self, X):
    #     x_temporal = self.temporal_conv_2(X.unsqueeze(-1)).squeeze(-1)
    #     for i, layer in enumerate(self.layers):
    #         # A = torch.randint(0, 2, (2, 27, 27)).float().cuda()
    #         if(i==0):
    #             x = layer(self.ajacency_matrix, X)
    #         else:
    #             x = layer(self.ajacency_matrix, x)
    #         if i != self.num_layer - 1:
    #             x = F.dropout(self.relu(x), self.dropout, training=self.training)
    #         else:
    #             x = F.dropout(x, self.dropout, training=self.training)
        
    #     x = torch.cat((x_temporal, x), dim=-1)
    #     x, (hn, cn) = self.lstm(x)  # !!!add
    #     # x = (x.sum(-1)/2) # bidirectional
    #     if(x.shape[-1]!=1):
    #         return x
    #     else:
    #         return x.squeeze(-1)

    # LSTM
    # def forward(self, X):
    #     x, (hn, cn) = self.lstm(X)  # !!!add
    #     x = (x.sum(-1)/2) # bidirectional
    #     if(x.shape[-1]!=1):
    #         return x
    #     else:
    #         return x.squeeze(-1)
