# how to save/load the model?

# the input/output dimension
